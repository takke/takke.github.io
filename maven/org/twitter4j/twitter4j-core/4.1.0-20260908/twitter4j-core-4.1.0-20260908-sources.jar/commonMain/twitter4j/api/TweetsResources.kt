/*
 * Copyright 2007 Yusuke Yamamoto
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package twitter4j.api

import twitter4j.*
import twitter4j.conf.ChunkedUploadConfiguration
import twitter4j.File
import twitter4j.InputStream

/**
 * @author Joern Huxhorn - jhuxhorn at googlemail.com
 */
interface TweetsResources {
    /**
     * Returns up to 100 of the first retweets of a given tweet.
     * <br>This method calls https://api.twitter.com/1.1/statuses/retweets
     *
     * @param statusId The numerical ID of the tweet you want the retweets of.
     * @return the retweets of a given tweet
     * @throws TwitterException when Twitter service or network is unavailable
     * @see <a href="https://dev.twitter.com/docs/api/1.1/get/statuses/retweets/:id">Tweets Resources › statuses/retweets/:id</a>
     * @since Twitter4J 2.0.10
     */
    @Throws(TwitterException::class)
    fun getRetweets(statusId: Long): ResponseList<Status>

    /**
     * Returns a collection of up to 100 user IDs belonging to users who have
     * retweeted the tweet specified by the id parameter.
     * <br>This method calls https://api.twitter.com/1.1/get/statuses/retweeters/ids
     *
     * @param statusId The numerical ID of the tweet you want the retweeters of.
     * @param cursor   The cursor of the page to fetch. Use -1 to start.
     * @return the retweets of a given tweet
     * @throws TwitterException when Twitter service or network is unavailable
     * @see <a href="https://dev.twitter.com/docs/api/1.1/get/statuses/retweeters/ids">Tweets Resources › statuses/retweeters/ids</a>
     * @since Twitter4J 3.0.5
     */
    @Throws(TwitterException::class)
    fun getRetweeterIds(statusId: Long, cursor: Long): IDs

    /**
     * Returns a collection of up to {@code count} user IDs belonging to users
     * who have retweeted the tweet specified by the id parameter.
     * <br>This method calls https://api.twitter.com/1.1/get/statuses/retweeters/ids
     *
     * @param statusId The numerical ID of the tweet you want the retweeters of.
     * @param count    The maximum number of retweeter IDs to retrieve. Must be
     *                 between 1 and 200, inclusive.
     * @param cursor   The cursor of the page to fetch. Use -1 to start.
     * @return the retweets of a given tweet
     * @throws TwitterException when Twitter service or network is unavailable
     * @see <a href="https://dev.twitter.com/docs/api/1.1/get/statuses/retweeters/ids">Tweets Resources › statuses/retweeters/ids</a>
     * @since Twitter4J 3.0.5
     */
    @Throws(TwitterException::class)
    fun getRetweeterIds(statusId: Long, count: Int, cursor: Long): IDs

    /**
     * Returns a single status, specified by the id parameter below. The status's author will be returned inline.
     * <br>This method calls https://api.twitter.com/1.1/statuses/show
     *
     * @param id the numerical ID of the status you're trying to retrieve
     * @return a single status
     * @throws twitter4j.TwitterException when Twitter service or network is unavailable
     * @see <a href="https://dev.twitter.com/docs/api/1.1/get/statuses/show/:id">GET statuses/show/:id | Twitter Developers</a>
     * @since Twitter4J 2.0.1
     */
    @Throws(TwitterException::class)
    fun showStatus(id: Long): Status

    /**
     * Destroys the status specified by the required ID parameter.<br>
     * Usage note: The authenticating user must be the author of the specified status.
     * <br>This method calls https://api.twitter.com/1.1/statuses/destroy
     *
     * @param statusId The ID of the status to destroy.
     * @return the deleted status
     * @throws TwitterException when Twitter service or network is unavailable
     * @see <a href="https://dev.twitter.com/docs/api/1.1/post/statuses/destroy/:id">POST statuses/destroy/:id | Twitter Developers</a>
     * @since 1.0.5
     */
    @Throws(TwitterException::class)
    fun destroyStatus(statusId: Long): Status

    /**
     * Updates the authenticating user's status. A status update with text identical to the authenticating user's text identical to the authenticating user's current status will be ignored to prevent duplicates.
     * <br>This method calls https://api.twitter.com/1.1/statuses/update
     *
     * @param status the text of your status update
     * @return the latest status
     * @throws TwitterException when Twitter service or network is unavailable
     * @see <a href="https://dev.twitter.com/docs/api/1.1/post/statuses/update">POST statuses/update | Twitter Developers</a>
     * @since Twitter4J 2.0.1
     */
    @Throws(TwitterException::class)
    fun updateStatus(status: String): Status

    /**
     * Updates the authenticating user's status. A status update with text identical to the authenticating user's text identical to the authenticating user's current status will be ignored to prevent duplicates.
     * <br>This method calls https://api.twitter.com/1.1/statuses/update or<br>
     * This method calls https://upload.twitter.com/1/statuses/update_with_media
     *
     * @param latestStatus the latest status to be updated.
     * @return the latest status
     * @throws TwitterException when Twitter service or network is unavailable
     * @see <a href="https://dev.twitter.com/docs/api/1.1/post/statuses/update">POST statuses/update | Twitter Developers</a>
     * @since Twitter4J 2.1.1
     */
    @Throws(TwitterException::class)
    fun updateStatus(latestStatus: StatusUpdate): Status

    /**
     * Retweets a tweet. Returns the original tweet with retweet details embedded.
     * <br>This method calls https://api.twitter.com/1.1/statuses/retweet
     *
     * @param statusId The ID of the status to retweet.
     * @return the retweeted status
     * @throws TwitterException when Twitter service or network is unavailable
     * @see <a href="https://dev.twitter.com/docs/api/1.1/post/statuses/retweet/:id">POST statuses/retweet/:id | Twitter Developers</a>
     * @since Twitter4J 2.0.10
     */
    @Throws(TwitterException::class)
    fun retweetStatus(statusId: Long): Status

    /**
     * Untweets a retweeted status. Returns the original Tweet with retweet details embedded.
     * <br>This method calls https://api.twitter.com/1.1/statuses/unretweet
     *
     * @param statusId The ID of the status to un-retweet.
     * @return the original Tweet with retweet details embedded
     * @throws TwitterException when Twitter service or network is unavailable
     * @see <a href="https://dev.twitter.com/docs/api/1.1/post/statuses/unretweet/:id">POST statuses/unretweet/:id | Twitter Developers</a>
     * @since Twitter4J 4.0.7
     */
    @Throws(TwitterException::class)
    fun unRetweetStatus(statusId: Long): Status

    /**
     * Returns fully-hydrated tweet objects for up to 100 tweets per request, as specified by comma-separated values passed to the id parameter.
     * This method is especially useful to get the details (hydrate) a collection of Tweet IDs.
     * <br>This method calls https://api.twitter.com/1.1/statuses/lookup.json
     *
     * @param ids array of the ids to lookup
     * @return list of the tweets
     * @throws TwitterException when Twitter service or network is unavailable
     * @see <a href="https://dev.twitter.com/docs/api/1.1/get/statuses/lookup">GET statuses/lookup</a>
     * @since Twitter4J 4.0.2
     */
    @Throws(TwitterException::class)
    fun lookup(vararg ids: Long): ResponseList<Status>

    /**
     * Uploads media image to be attached via {@link #updateStatus(twitter4j.StatusUpdate)}
     * <br>This method calls https://api.twitter.com/1.1/media/upload.json
     *
     * @param mediaFile media file
     * @return upload result
     * @throws TwitterException when Twitter service or network is unavailable
     * @see <a href="https://dev.twitter.com/docs/api/1.1/post/statuses/update">POST statuses/update | Twitter Developers</a>
     * @see <a href="https://dev.twitter.com/docs/api/multiple-media-extended-entities">Multiple Media Entities in Statuses</a>
     * @since Twitter4J 4.0.2
     */
    @Throws(TwitterException::class)
    fun uploadMedia(mediaFile: File): UploadedMedia

    /**
     * Uploads media image to be attached via {@link #updateStatus(twitter4j.StatusUpdate)}
     * <br>This method calls https://api.twitter.com/1.1/media/upload.json
     *
     * @param fileName media file name
     * @param media media body as stream
     * @return upload result
     * @throws TwitterException when Twitter service or network is unavailable
     * @see <a href="https://dev.twitter.com/docs/api/1.1/post/statuses/update">POST statuses/update | Twitter Developers</a>
     * @see <a href="https://dev.twitter.com/docs/api/multiple-media-extended-entities">Multiple Media Entities in Statuses</a>
     * @since Twitter4J 4.0.3
     */
    @Throws(TwitterException::class)
    fun uploadMedia(fileName: String, media: InputStream): UploadedMedia

    /**
     * Uploads media using chunked approach to be attached via {@link #updateStatus(twitter4j.StatusUpdate)}.
     * This should be used for videos.
     * <br>This method calls https://api.twitter.com/1.1/media/upload.json
     *
     * @param chunkedUploadConfiguration Configuration for chunked uploading
     * @return upload result
     * @throws TwitterException when Twitter service or network is unavailable
     * @see <a href="https://dev.twitter.com/rest/public/uploading-media#chunkedupload">Uploading Media | Twitter Developers</a>
     * @see <a href="https://dev.twitter.com/docs/api/1.1/post/statuses/update">POST statuses/update | Twitter Developers</a>
     * @see <a href="https://dev.twitter.com/docs/api/multiple-media-extended-entities">Multiple Media Entities in Statuses</a>
     * @since Twitter4J 4.0.7
     */
    @Throws(TwitterException::class)
    fun uploadMediaChunked(chunkedUploadConfiguration: ChunkedUploadConfiguration): UploadedMedia

    /**
     * Creates metadata to the uploaded media image
     * <br>This method calls https://api.twitter.com/1.1/media/metadata/create.json
     *
     * @param mediaId media id
     * @param altText alt text
     * @return 200 (success), 4xx (Bad Request), 5xx (server error)
     * @throws TwitterException when Twitter service or network is unavailable
     * @since Twitter4J 4.0.x
     */
    @Throws(TwitterException::class)
    fun createMediaMetadata(mediaId: Long, altText: String): Int
}
