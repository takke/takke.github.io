/*
 * Copyright 2007 Yusuke Yamamoto
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package twitter4j

/**
 * A data interface representing search API response
 *
 * @author Yusuke Yamamoto - yusuke at mac.com
 */
interface QueryResult : TwitterResponse, Serializable {
    val sinceId: Long

    val maxId: Long

    val refreshURL: String

    val count: Int

    val completedIn: Double

    val query: String

    val tweets: List<Status>

    /**
     * Returns a Query instance to fetch next page or null if there is no next page.
     *
     * @return Query instance to fetch next page
     * @since Twitter4J 3.0.0
     */
    fun nextQuery(): Query?

    /**
     * test if there is next page
     *
     * @return if there is next page
     * @since Twitter4J 3.0.0
     */
    fun hasNext(): Boolean
}
