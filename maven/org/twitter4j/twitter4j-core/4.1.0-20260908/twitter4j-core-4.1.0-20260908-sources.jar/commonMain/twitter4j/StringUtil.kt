/*
 * Copyright 2007 Yusuke Yamamoto
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package twitter4j

import kotlin.jvm.JvmStatic

/**
 * @author Yusuke Yamamoto - yusuke at mac.com
 * @since Twitter4J 2.1.4
 */
internal object StringUtil {

    @JvmStatic
    fun join(follows: LongArray): String {
        val buf = StringBuilder(11 * follows.size)
        for (follow in follows) {
            if (0 != buf.length) {
                buf.append(",")
            }
            buf.append(follow)
        }
        return buf.toString()
    }

    @JvmStatic
    fun join(track: Array<String>): String {
        val buf = StringBuilder(11 * track.size)
        for (str in track) {
            if (0 != buf.length) {
                buf.append(",")
            }
            buf.append(str)
        }
        return buf.toString()
    }
}
