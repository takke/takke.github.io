package mastodon4j.api.entity

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import mastodon4j.api.entity.util.CalckeyCompatUtil

// import mastodon4j.api.entity.util.CalckeyCompatUtil

@Serializable
data class Account(
    @SerialName("id") val id: String = "",
    @SerialName("username") val userName: String = "",
    @SerialName("acct") val acct: String = "",
    @SerialName("display_name") val displayName_: String? = "",     // null when calckey.jp
    @SerialName("note") val note_: String? = "",                    // null when calckey.jp
    @SerialName("url") val url: String = "",
    @SerialName("avatar") val avatar: String = "",
    @SerialName("avatar_static") val avatarStatic: String = "",
    @SerialName("header") val header_: String? = "",                // null when calckey.jp
    @SerialName("header_static") val headerStatic_: String? = "",   // null when calckey.jp
    @SerialName("locked") val isLocked: Boolean = false,
    @SerialName("created_at") val createdAt: String = "",
    @SerialName("followers_count") val followersCount: Long = 0,
    @SerialName("following_count") val followingCount: Long = 0,
    @SerialName("statuses_count") val statusesCount: Long = 0,

    // Fedibird 拡張: アカウントの購読者数
    // see https://fedibird.com/@info/103308964302566365
    @SerialName("subscribing_count") val subscribingCount: Long = 0,
    @SerialName("emojis") val emojis: List<Emoji> = emptyList(),
    @SerialName("fields") val fields: List<Field> = emptyList(),

    // for fedibird.com
    @SerialName("other_settings") val otherSettings: AccountOtherSettings? = null,
) {
    val idAsLong: Long by lazy { CalckeyCompatUtil.toLongOrCalckeyIdOrFakeTimeId(id, createdAt) }

    val displayName: String get() = displayName_ ?: ""
    val note: String get() = note_ ?: ""
    val header: String get() = header_ ?: ""
    val headerStatic: String get() = headerStatic_ ?: ""
}
